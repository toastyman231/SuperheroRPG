using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour
{
    [SerializeField] OldPlayerMovement movement;
    [SerializeField] MouseLook mouseLook;
    PlayerControls controls;
    PlayerControls.GameplayActions gameplayActions;
    Vector2 horizontalInput;
    Vector2 mouseInput;

    private void Awake()
    {
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;
        controls = new PlayerControls();
        gameplayActions = controls.Gameplay;

        gameplayActions.Horizontal.performed += ctx => horizontalInput = ctx.ReadValue<Vector2>();
        gameplayActions.Jump.performed += _ => movement.OnJumpPressed();
        gameplayActions.XLook.performed += ctx => mouseInput.x = ctx.ReadValue<float>();
        gameplayActions.YLook.performed += ctx => mouseInput.y = ctx.ReadValue<float>();
        gameplayActions.Sprint.performed += _ => movement.OnSprintPressed();
        gameplayActions.Crouch.performed += _ => movement.OnCrouchPressed();
        gameplayActions.Slide.performed += _ => movement.OnSlidePressed();
    }

    private void OnEnable()
    {
        controls.Enable();
    }

    private void OnDisable()
    {
        controls.Disable();
    }

    private void Update()
    {
        movement.ReceiveInput(horizontalInput);
        mouseLook.ReceiveInput(mouseInput);
    }
}
