using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityAsync;

public class OldPlayerMovement : MonoBehaviour
{
#pragma warning disable 649
    [SerializeField] CharacterController controller;
    [SerializeField] float speed = 11f;
    [SerializeField] float slideSpeed = 30f;
    [SerializeField] float gravity = -30f;
    [SerializeField] float jumpHeight = 3.5f;
    [SerializeField] float sprintMultiplier = 1.5f;
    [SerializeField] float crouchSpeed = 0.1f;
    [SerializeField] LayerMask ground;
    [SerializeField] LayerMask wallrun;
    float defaultSpeed = 11f;
    float slideTimer;
    bool jump;
    bool slide;
    bool sprinting = false;
    bool crouching = false;
    public bool isGrounded;
    public bool onWall;
    Vector3 verticalVelocity = Vector3.zero;
    Vector2 horizontalInput;

    private void Update()
    {
        isGrounded = Physics.CheckSphere(transform.position, 0.1f, ground);
        onWall = Physics.CheckSphere(transform.position, 0.1f, wallrun);

        if(isGrounded)
        {
            verticalVelocity.y = 0;
        }

        if(slide)
        {
            controller.Move(transform.forward * slideSpeed * Time.deltaTime);
            slideTimer += Time.deltaTime;
            if(slideTimer >= 1.5f)
            {
                slide = false;
                OnCrouchPressed();
            }
        }

        Vector3 horizontalVelocity = (transform.right * horizontalInput.x + transform.forward * horizontalInput.y) * speed;
        controller.Move(horizontalVelocity * Time.deltaTime);

        if(jump)
        {
            verticalVelocity.y = Mathf.Sqrt(-2 * jumpHeight * gravity);
            jump = false;
        }

        verticalVelocity.y += gravity * Time.deltaTime;
        controller.Move(verticalVelocity * Time.deltaTime);
    }

    public void ReceiveInput(Vector2 horInput)
    {
        horizontalInput = horInput;
        //print(horizontalInput);
    }

    public void OnJumpPressed()
    {
        if(isGrounded)
        {
            jump = true;
        }
    }

    public void OnSprintPressed()
    {
        sprinting = !sprinting;

        if(sprinting)
        {
            speed *= sprintMultiplier;
        } else
        {
            speed = defaultSpeed;
        }
    }

    public void OnSlidePressed()
    {
        slide = true;
        slideTimer = 0.0f;
        OnCrouchPressed();
    }

    public void OnCrouchPressed()
    {
        crouching = !crouching;
        if(sprinting) { sprinting = false; speed = defaultSpeed; }

        if(crouching)
        {
            //transform.localScale = Vector3.Lerp(transform.localScale, new Vector3(transform.localScale.x, 0.5f, transform.localScale.z), Time.deltaTime);
            LerpScale(new Vector3(transform.localScale.x, 0.5f, transform.localScale.z), crouchSpeed);
        } else
        {
            //transform.localScale = Vector3.one;
            LerpScale(Vector3.one, crouchSpeed);
        }
    }

    private async void LerpScale(Vector3 target, float duration)
    {
        float time = 0f;
        Vector3 startPos = transform.localScale;

        while(time < duration)
        {
            transform.localScale = Vector3.Lerp(startPos, target, time / duration);
            time += Time.deltaTime;
            await Await.NextUpdate();
        }

        transform.localScale = target;
    }
}
